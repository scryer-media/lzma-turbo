"""Predeclared balanced fixed-source T16 confirmation: each binary occupies every position twice across all six permutations; separate warmup. All wall/CPU/RSS, decoded hashes, preceding product and official SDK controls retained. No source change or result-dependent stopping."""
import hashlib,json,os,statistics,subprocess,time,sys
from pathlib import Path
root=Path.cwd(); fleet=Path("/opt/turbo-validation")
out=root/"target/fleet/current-t16-shared-cursor/controls"
out.mkdir(exist_ok=False,parents=True)
fixtures=fleet/"sz-fixtures/src"
binaries={"baseline":root/"target/fleet/current-t16-sdk-fixed/candidate","candidate":root/"target/fleet/current-t16-shared-cursor/candidate","reference":fleet/"official/7zz"}
def digest(p):
 with p.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
assert digest(binaries["baseline"])==json.loads((fleet/"evidence/binary-hashes.json").read_text())["baseline"]
assert digest(binaries["reference"])==json.loads((fleet/"evidence/binary-hashes.json").read_text())["reference"]
assert len(sys.argv)==2 and digest(binaries["candidate"])==sys.argv[1]
assert all(key not in binaries["candidate"].read_bytes() for key in (b"LZMA_TURBO_MIXER",b"LZMA_TURBO_BT_ASM",b"LZMA_TURBO_ENCODER"))
data={"note":__doc__,"binary_sha256":{k:digest(v) for k,v in binaries.items()},"arm_selection":{"baseline":"preceding ARM production defaults with indexed record cursor, high-hash proof and retained-span Skip","candidate":"same ARM production tree and mixer defaults with scoped shared produced-record cursor in GetMatches and Skip; no kernel-ab selectors","reference":"official ARM64 SDK26.03 prebuilt"},"source_sha256":{},"fixture_sha256":{},"samples":[],"load_checks":[]}
for label,repo in [("lzma",fleet/"lzma-turbo/.worktrees/mac-fleet-perf"),("sevenz",root)]:
 for p in sorted((repo/"src").rglob("*")):
  if p.is_file() and not p.name.startswith("._"):data["source_sha256"][label+"/"+str(p.relative_to(repo))]=digest(p)
def check_load():
 busy=[]
 for line in subprocess.check_output(["ps","-A","-o","pcpu=,comm="],text=True).splitlines():
  fields=line.strip().split(None,1)
  if len(fields)!=2:continue
  cpu,cmd=fields;cmd=Path(cmd).name
  if cmd in ("rustc","cargo","clang","ld","cc1","cc1plus"):busy.append({"process":cmd,"cpu_percent":float(cpu)})
 data["load_checks"].append({"time":time.monotonic(),"interference":busy})
 return busy
assert not check_load()
# Only T16 ordinary/AES/zeros until the full-thread gap is resolved.
cases=[(5,16,False,False,False),(5,16,False,True,False),(5,16,True,False,False)]
summary=[]
for level,threads,zeros,encrypted,tiny in cases:
 source=(root/"target/fleet/current-encoder-batch/fixtures/zeros") if zeros else fixtures/("kdf-tree" if tiny else "payload-sub")
 for p in sorted(source.rglob("*")):
  if p.is_file():data["fixture_sha256"][source.name+"/"+str(p.relative_to(source))]=digest(p)
 assert data["fixture_sha256"][source.name+"/"+("zeros.bin" if zeros else "payload-sub.bin")] == {'payload-sub/.complete': 'b068396d5c99b1aef7eec6d17a575adebf7264164234833aebdfa3f1c5b52386', 'payload-sub/payload-sub.bin': '1f01b30af4ef1142dc8fc0c9f7298028d029ea163b385e9d87b8ef15079498a6', 'zeros/zeros.bin': '9acca8e8c22201155389f65abbf6bc9723edc7384ead80503839f49dcc56d767'}[source.name+"/"+("zeros.bin" if zeros else "payload-sub.bin")]
 assert (source/("zeros.bin" if zeros else "payload-sub.bin")).stat().st_size == (536870912 if zeros else 268435456)
 case=("zeros/" if zeros else "kdf-tree/" if tiny else "payload-sub/")+f"L{level}/T{threads}"+("/aes" if encrypted else "")+("/non-solid" if tiny else "")
 hashes={arm:set() for arm in binaries if arm!="reference"}
 orders = [("baseline","candidate","reference"),
           ("baseline","candidate","reference"),
           ("candidate","reference","baseline"),
           ("reference","baseline","candidate"),
           ("reference","candidate","baseline"),
           ("candidate","baseline","reference"),
           ("baseline","reference","candidate")]
 assert len(set(orders[1:])) == 6
 assert all(sum(order[position] == arm for order in orders[1:]) == 2 for arm in binaries for position in range(3))
 data["measured_orders"] = orders[1:]
 data["warmup_order"] = orders[0]
 for iteration,arms in enumerate(orders):
  for arm in arms:
   slug=case.replace("/","-")+f"-{iteration}-{arm}";archive=out/(slug+".7z");usage=out/(slug+".usage.json")
   if arm!="reference":
    args=["op","encode","--input",str(source),"--out",str(archive),"--level",str(level),"--threads",str(threads)]
    if encrypted:args += ["--password","bench-passphrase"]
    if tiny:args += ["--non-solid"]
   else:
    settings={1:"d=1m:fb=128:mf=hc4:a=0:mc=8",3:"d=4m:fb=273:mf=hc4:a=0:mc=48",5:"d=8m:fb=32:mf=bt4:a=1"}[level]
    args=["a","-bso0","-bsp0","-y","-t7z","-m0=lzma2:"+settings,f"-mx={level}",f"-mmt={threads}","-ms=off" if tiny else "-ms=on",str(archive),"." if tiny else "zeros.bin" if zeros else "payload-sub.bin"]
    if encrypted:args += ["-pbench-passphrase","-mhe=on"]
   with (out/(slug+".stdout")).open("w") as so,(out/(slug+".stderr")).open("w") as se:
    child=subprocess.Popen([str(root/"target/fleet/measure-child"),str(usage),str(binaries[arm]),*args],cwd=source,stdout=so,stderr=se,env={k:v for k,v in os.environ.items() if not k.startswith("LZMA_TURBO_")})
    while child.poll() is None:check_load();time.sleep(.25)
   assert child.returncode==0,(slug,child.returncode)
   verify=[str(binaries["reference"]),"t","-bso0","-bsp0",str(archive)]
   if encrypted:verify += ["-pbench-passphrase"]
   subprocess.run(verify,check=True,stdout=subprocess.DEVNULL)
   extract=[str(binaries["reference"]),"x","-so","-bsp0",str(archive)]
   if encrypted:extract += ["-pbench-passphrase"]
   child=subprocess.Popen(extract,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   restored=hashlib.file_digest(child.stdout,"sha256").hexdigest()
   error=child.stderr.read();assert child.wait()==0,error
   expected=digest(source/("zeros.bin" if zeros else "payload-sub.bin"))
   assert restored==expected,(slug,restored,expected)
   product=None
   if arm!="reference":
    product=json.loads((out/(slug+".stdout")).read_text());assert product["ok"] and product["crypto_backend"]=="aws-lc"
   sha=digest(archive)
   if arm!="reference" and not encrypted:hashes[arm].add(sha)
   row={"case":case,"arm":arm,"iteration":iteration,"warmup":iteration==0,**json.loads(usage.read_text()),"archive_bytes":archive.stat().st_size,"archive_sha256":sha,"integrity":True,"decoded_sha256":restored,"product":product}
   row["cpu"]=row["user"]+row["sys"];data["samples"].append(row)
   (out/"raw.json").write_text(json.dumps(data,indent=2)+"\n")
   print(slug,round(row["wall"],4),round(row["cpu"],4),round(row["rss_bytes"]/2**20,3),flush=True)
   archive.unlink()
 if not encrypted:assert len(hashes["baseline"])==1 and all(v==hashes["baseline"] for v in hashes.values()),(case,hashes)
 medians={arm:{k:statistics.median(r[k] for r in data["samples"] if r["case"]==case and r["arm"]==arm and not r["warmup"]) for k in ("wall","cpu","rss_bytes","archive_bytes")} for arm in binaries}
 summary.append({"case":case,"medians":medians,"ranges":{arm:{k:[min(r[k] for r in data["samples"] if r["case"]==case and r["arm"]==arm and not r["warmup"]),max(r[k] for r in data["samples"] if r["case"]==case and r["arm"]==arm and not r["warmup"])] for k in ("wall","cpu","rss_bytes")} for arm in binaries},"candidate_over_baseline":{k:medians["candidate"][k]/medians["baseline"][k] for k in medians["candidate"]},"candidate_over_reference":{k:medians["candidate"][k]/medians["reference"][k] for k in medians["candidate"]},"plain_archive_bytes_identical":not encrypted})
 (out/"report.json").write_text(json.dumps(summary,indent=2)+"\n")
 print("CASE",json.dumps(summary[-1]),flush=True)
assert not any(r["interference"] for r in data["load_checks"]),"cohort contaminated: preserve, do not call it accepted"
