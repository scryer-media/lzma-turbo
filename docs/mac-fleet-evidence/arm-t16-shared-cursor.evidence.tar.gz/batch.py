import os,subprocess,json,hashlib,time,shutil,platform
from pathlib import Path
base=Path('/opt/turbo-validation');out=base/'evidence';out.mkdir(exist_ok=True)
lzma=base/'lzma-turbo/.worktrees/mac-fleet-perf';seven=base/'sevenz-turbo/.worktrees/mac-fleet-perf'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def sources(root):
 return {label+'/'+str(p.relative_to(repo)):digest(p) for label,repo in [('lzma',root/'lzma-turbo/.worktrees/mac-fleet-perf'),('sevenz',root/'sevenz-turbo/.worktrees/mac-fleet-perf')] for p in sorted((repo/'src').rglob('*')) if p.is_file() and not p.name.startswith('._')}
expected=json.loads((base/'expected-source-hashes.json').read_text());assert sources(base)==expected
(out/'source-hashes.json').write_text(json.dumps(expected,indent=2))
whole=json.loads((base/'whole-source-manifest.json').read_text())
for key,value in whole.items():
 label,name=key.split('/',1); assert digest(base/(label+'-turbo')/'.worktrees/mac-fleet-perf'/name)==value,key
shutil.copyfile(base/'whole-source-manifest.json',out/'whole-source-manifest.json')
for name in ['lzma-turbo','sevenz-turbo']:
 shutil.copytree(base/name,base/'baseline'/name,ignore=shutil.ignore_patterns('target','.git'))
previous=base/'preceding-lz_find_mt.rs';assert digest(previous)=='700be07fa2e14420edf306df0b61c2e054207bb3e6dae8505933383fa3b94d22'
shutil.copyfile(previous,base/'baseline/lzma-turbo/.worktrees/mac-fleet-perf/src/enc/lz_find_mt.rs')
baseline=sources(base/'baseline');diff=[k for k in expected if expected[k]!=baseline[k]];assert diff==['lzma/src/enc/lz_find_mt.rs'];(out/'baseline-source-hashes.json').write_text(json.dumps(baseline,indent=2))
env=os.environ.copy();env.update(CARGO_HOME=str(base/'cargo'),RUSTUP_HOME=str(base/'rustup'),CARGO_BUILD_JOBS='8',LZMA_SDK=str(base/'sdk'),LZMA_ORACLE_REQUIRE='1',LZMA_ORACLE_REQUIRE_ASM='1',LZMA_ENCODER_ORACLE_REQUIRE='1',LZMA_TURBO_LZMA_UTIL_REQUIRE='1',LZMA_TURBO_7ZZ=str(base/'bin/7zz'),LZMA_TURBO_7ZZ_REQUIRE='1',LZMA_TURBO_XZ_REQUIRE='1',LZMA_TURBO_XZ_TESTS_REQUIRE='1',LZMA_TURBO_BCJ2='sdk')
env['PATH']=str(base/'cargo/bin')+':'+str(base/'bin')+':'+str(base/'xz/bin')+':'+env['PATH'];rows=[]
def run(name,repo,args,extra=None):
 start=time.monotonic();e=env.copy();e.update(extra or {})
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(['/usr/bin/time','-v',*args],cwd=repo,env=e,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,args=args,exit=r.returncode,seconds=time.monotonic()-start));(out/'validation.json').write_text(json.dumps(rows,indent=2));print(name,r.returncode,flush=True);return r.returncode
with (out/'platform.log').open('w') as f:
 for args in [['uname','-a'],['lscpu'],['rustc','-Vv'],['cargo','-V'],[str(base/'official/7zz'),'i'],['xz','--version'],['git','-C',str(base/'sdk'),'rev-parse','HEAD']]:subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
assert subprocess.check_output(['git','-C',str(base/'sdk'),'rev-parse','HEAD'],text=True).strip()=='0766b733fe3e06dd2a7f9a3cfbf2108ac73abd17'
version=subprocess.check_output([str(base/'official/7zz'),'i'],text=True);assert '26.03' in version and 'arm64' in version.lower(),version
(out/'reference-provenance.json').write_text(json.dumps({'url':'https://www.7-zip.org/a/7z2603-linux-arm64.tar.xz','package_sha256':digest(base/'official/official-sdk.tar.xz'),'binary_sha256':digest(base/'official/7zz'),'version':version,'oracle_binary_sha256':digest(base/'bin/7zz'),'oracle_kind':'separately source-built pinned SDK','architecture_note':'ARM64 production uses its existing portable/register tree and current mixer defaults; only record cursor consumption differs between product arms.'},indent=2))
for name,args in [('lzma-util',['cargo','run','--locked','-p','xtask','--','lzma-util']),('xz-tests',['cargo','run','--locked','-p','xtask','--','xz-tests'])]:
 if run(name,lzma,args):raise SystemExit(1)
for name,repo in [('lzma',lzma),('sevenz',seven)]:
 run(name+'-all',repo,['cargo','test','--locked','--workspace','--exclude','wasm-conformance','--all-features','--no-fail-fast'])
 run(name+'-default',repo,['cargo','test','--locked','-p',name+'-turbo','--no-fail-fast'])
run('lzma-no-std',lzma,['cargo','check','--locked','-p','lzma-turbo','--no-default-features'])
run('lzma-encoder-only',lzma,['cargo','check','--locked','-p','lzma-turbo','--no-default-features','--features','enc'])
run('sevenz-send-unthreaded',seven,['cargo','test','--locked','-p','sevenz-turbo','--test','send_input_tests','--no-fail-fast'],{'RUSTFLAGS':'--cfg sevenz_turbo_unthreaded'})
run('guard-pages',lzma,['cargo','test','--locked','-p','lzma-turbo','--all-features','--test','guard_pages','--no-fail-fast','--','--include-ignored','--test-threads=1'])
run('production-build',seven,['cargo','build','--locked','--release','-p','decode-bench'])
run('baseline-build',base/'baseline/sevenz-turbo/.worktrees/mac-fleet-perf',['cargo','build','--locked','--release','-p','decode-bench'])
if any(r['exit'] for r in rows):raise SystemExit('Native validation failed: preserve all logs; no timing')
for label,src,rel in [('candidate',seven/'target/release/decode-bench','current-t16-shared-cursor'),('baseline',base/'baseline/sevenz-turbo/.worktrees/mac-fleet-perf/target/release/decode-bench','current-t16-sdk-fixed')]:
 dst=seven/'target/fleet'/rel/'candidate';dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);dst.chmod(0o755)
subprocess.run(['cc','-O2',str(base/'measure_child.c'),'-o',str(seven/'target/fleet/measure-child')],check=True)
zero=seven/'target/fleet/current-encoder-batch/fixtures/zeros/zeros.bin';zero.parent.mkdir(parents=True,exist_ok=True)
with zero.open('wb') as f:
 for _ in range(512):f.write(bytes(1<<20))
assert digest(zero)=='9acca8e8c22201155389f65abbf6bc9723edc7384ead80503839f49dcc56d767'
payload=base/'sz-fixtures/src/payload-sub/payload-sub.bin';assert digest(payload)=='1f01b30af4ef1142dc8fc0c9f7298028d029ea163b385e9d87b8ef15079498a6'
for p in [payload,zero]:os.utime(p,(1700000000,1700000000))
bins={'candidate':seven/'target/fleet/current-t16-shared-cursor/candidate','baseline':seven/'target/fleet/current-t16-sdk-fixed/candidate','reference':base/'official/7zz'}
(out/'binary-hashes.json').write_text(json.dumps({k:digest(v) for k,v in bins.items()},indent=2))
(out/'ready.json').write_text(json.dumps({'success':True,'native_checks':len(rows),'source':expected['lzma/src/enc/lz_find_mt.rs']}));print('READY_FOR_COHORT',flush=True)
