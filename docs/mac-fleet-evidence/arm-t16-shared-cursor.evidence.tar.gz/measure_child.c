#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

int main(int argc, char **argv) {
    if (argc < 3) return 2;
    struct timespec start, end;
    struct rusage usage;
    int status;
    clock_gettime(CLOCK_MONOTONIC, &start);
    pid_t child = fork();
    if (child < 0) return 2;
    if (child == 0) {
        execvp(argv[2], argv + 2);
        _exit(127);
    }
    while (wait4(child, &status, 0, &usage) < 0) {
        if (errno != EINTR) return 2;
    }
    clock_gettime(CLOCK_MONOTONIC, &end);
    FILE *out = fopen(argv[1], "w");
    if (!out) return 2;
    double wall = end.tv_sec-start.tv_sec + (end.tv_nsec-start.tv_nsec)*1e-9;
    double user = usage.ru_utime.tv_sec + usage.ru_utime.tv_usec*1e-6;
    double sys = usage.ru_stime.tv_sec + usage.ru_stime.tv_usec*1e-6;
    long rss = usage.ru_maxrss;
#ifdef __linux__
    rss *= 1024;
#endif
    fprintf(out, "{\"wall\":%.9f,\"user\":%.9f,\"sys\":%.9f,\"rss_bytes\":%ld}\n", wall, user, sys, rss);
    if (fclose(out)) return 2;
    return WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status);
}
